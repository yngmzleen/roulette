-- Table: public.Users

-- DROP TABLE IF EXISTS public."Users";

--CREATE TABLE IF NOT EXISTS public."Users"
--(
 --   user_id bigint NOT NULL,
 --   " balance " bigint NOT NULL,
 --   CONSTRAINT "Users_pkey" PRIMARY KEY (user_id)
--)
--
--TABLESPACE pg_default;

--ALTER TABLE IF EXISTS public."Users"
 --   OWNER to postgres;